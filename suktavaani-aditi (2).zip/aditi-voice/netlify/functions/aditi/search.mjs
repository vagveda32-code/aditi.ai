// Local search over the Atharvaveda text (Dr. Ganga Sahay Sharma, Hindi translation, Shaunaka Samhita).
// data: [{ k: kanda, s: sukta, d: devata, t: topic (from contents), x: mantras + meaning }]
import DATA from "./data.mjs";

const DIGITS = { "०": 0, "१": 1, "२": 2, "३": 3, "४": 4, "५": 5, "६": 6, "७": 7, "८": 8, "९": 9,
  "೦": 0, "೧": 1, "೨": 2, "೩": 3, "೪": 4, "೫": 5, "೬": 6, "೭": 7, "೮": 8, "೯": 9,
  "౦": 0, "౧": 1, "౨": 2, "౩": 3, "౪": 4, "౫": 5, "౬": 6, "౭": 7, "౮": 8, "౯": 9 };
const toAscii = (s) => s.replace(/[०-९೦-೯౦-౯]/g, (c) => DIGITS[c]);

// Hindi ordinal / number words for kanda (1–20)
const NUMW = [
  [/पहल|प्रथम/, 1], [/दूसर|द्वितीय/, 2], [/तीसर|तृतीय/, 3], [/चौथ|चतुर्थ/, 4], [/पांच|पाँच|पंचम/, 5],
  [/छठ|षष्ठ/, 6], [/सातव|सप्तम/, 7], [/आठव|अष्टम/, 8], [/नौव|नवम/, 9], [/दसव|दशम/, 10],
  [/ग्यारह|एकादश/, 11], [/बारह|द्वादश/, 12], [/तेरह|त्रयोदश/, 13], [/चौदह|चतुर्दश/, 14], [/पंद्रह|पन्द्रह|पंचदश/, 15],
  [/सोलह|षोडश/, 16], [/सत्रह|सप्तदश/, 17], [/अठारह|अष्टादश/, 18], [/उन्नीस|एकोनविंश/, 19], [/बीसव|विंश/, 20],
];

// Well-known sukta names → [kanda, sukta] — इस ग्रंथ (डा. गंगा सहाय शर्मा) की क्रम-संख्या के अनुसार
const ALIASES = [
  [/भूमि\s*सूक्त|पृथ्वी\s*सूक्त|पृथिवी\s*सूक्त|माता\s*भूमि|पृथ्वी.{0,20}माता|माता.{0,20}पृथ्वी|bhumi|prithvi|ಭೂಮಿ|భూమి/i, [12, 1]],
  [/ब्रह्मचर्य\s*सूक्त|ब्रह्मचारी\s*सूक्त|brahmachar/i, [11, 7]],
  [/काल\s*सूक्त|kaal\s*sukt|kala\s*sukt/i, [19, 53]],
  [/स्कम्भ|स्कंभ|skambh/i, [10, 7]],
  [/प्राण\s*सूक्त|prana\s*sukt/i, [11, 6]],
  [/रोहित\s*सूक्त|rohit/i, [13, 1]],
  [/उच्छिष्ट|uchchhisht|ucchisht/i, [11, 9]],
  [/सांमनस्य|सामनस्य|सौमनस्य|saamanasy|samanasy/i, [3, 30]],
  [/विवाह|vivah|सूर्या\s*सूक्त/i, [14, 1], [14, 2]],
  [/शाला|घर\s*(बनाने|निर्माण)|वास्तु|vastu|shala/i, [3, 12], [9, 3]],
  [/कुंताप|कुन्ताप|kuntap/i, [20, 127]],
  [/व्रात्य|vratya/i, [15, 1]],
  [/वेदमाता|गायत्री\s*सूक्त|vedamata/i, [19, 71]],
  [/मधु\s*विद्या|मधुविद्या|मधुकशा|madhu\s*vidya/i, [9, 1]],
];

const norm = (s) => s.normalize("NFC").replace(/\u093C/g, "").replace(/\u0901/g, "\u0902").replace(/[\u0970\u093D\u0951\u0952\u0903:]/g, "");
const STOP = new Set(("का की के को में से है हैं और या भी तो यह वह इस उस एक कर करो बताओ बताइए बताएं बताइये बताना बताये क्या कौन कौनसा कौन-सा " +
  "सूक्त सूक्तों मंत्र मंत्रों अर्थ महत्त्व महत्व संदेश देवता ऋषि कांड काण्ड संख्या मुझे हमें आप तुम अदिति अथर्ववेद वेद " +
  "स्तुति स्तुतियों वर्णन प्रशंसा आराधना देव देवी देवों कामना प्रार्थना जी कृपया दो दीजिए लिए बारे सुनाओ सुनाइए स्क्रिप्ट वॉइसओवर चाहिए होता होती गया गई जाता जाती करता करती करते हे").split(" "));
const stem = (w) => w.replace(/(ियों|ाओं|ाएं|ाएँ|ों|ें|ीं|ियां|ियाँ|ाओ|ता|ती|ते|ना|नी|ने|ी|ा|े|ो|ि|ु)$/u, "");
const words = (s) => (norm(s).match(/[ऀ-ॿ]+|[a-z]+/gi) || []).map((w) => w.toLowerCase());
const terms = (s) => words(s).filter((w) => w.length > 1 && !STOP.has(w)).map(stem).filter((w) => w.length > 1);

// ---- index (built once per cold start) ----
const DOCS = DATA.map((r, i) => {
  const tf = new Map();
  const addAll = (str, w) => { for (const t of terms(str)) tf.set(t, (tf.get(t) || 0) + w); };
  addAll(r.t || "", 3); addAll(r.d || "", 6); addAll(r.x || "", 1);
  let len = 0; for (const v of tf.values()) len += v;
  return { i, tf, len };
});
const DF = new Map();
for (const d of DOCS) for (const t of d.tf.keys()) DF.set(t, (DF.get(t) || 0) + 1);
const AVG = DOCS.reduce((n, d) => n + d.len, 0) / DOCS.length;
const BY = new Map(DATA.map((r, i) => [r.k + "." + r.s, i]));

function explicitRef(q) {
  const s = toAscii(q);
  let m = s.match(/(\d{1,2})\s*[.\/:,-]\s*(\d{1,3})/);
  if (m && BY.has(+m[1] + "." + +m[2])) return [+m[1], +m[2]];
  let k = null, su = null;
  const KW = "(?:कांड|काण्ड|कान्ड|kand|kaand|ಕಾಂಡ|కాండ)";
  for (const [re, n] of NUMW) if (new RegExp("(" + re.source + ")\\S*\\s*(कांड|काण्ड)").test(s)) { k = n; break; }
  if (!k) {
    m = s.match(new RegExp("(\\d{1,2})\\D{0,6}" + KW, "i")) || s.match(new RegExp(KW + "\\D{0,6}(\\d{1,2})", "i"));
    if (m && +m[1] >= 1 && +m[1] <= 20) k = +m[1];
  }
  m = s.match(/(?:सूक्त|sukt|ಸೂಕ್ತ|సూక్త)\D{0,6}(\d{1,3})/i) || s.match(/(\d{1,3})\D{0,8}(?:सूक्त|sukt|ಸೂಕ್ತ|సూక్త)/i);
  if (m) su = +m[1];
  if (k && su === k && (s.match(/\d{1,3}/g) || []).length === 1) su = null;
  if (k && su && BY.has(k + "." + su)) return [k, su];
  if (k && !su) return [k, 0];
  return null;
}

export function search(query, n = 3) {
  const out = [], seen = new Set();
  const push = (i) => { if (i != null && !seen.has(i)) { seen.add(i); out.push(DATA[i]); } };
  const ref = explicitRef(query);
  if (ref && ref[1]) push(BY.get(ref[0] + "." + ref[1]));
  for (const [re, ...refs] of ALIASES) if (re.test(query)) for (const [k, s] of refs) push(BY.get(k + "." + s));
  const qt = [...new Set(terms(query))];
  if (qt.length) {
    const N = DOCS.length, scored = [];
    for (const d of DOCS) {
      if (ref && !ref[1] && DATA[d.i].k !== ref[0]) continue;
      let sc = 0;
      for (const t of qt) {
        const f = d.tf.get(t); if (!f) continue;
        const idf = Math.log(1 + (N - DF.get(t) + 0.5) / (DF.get(t) + 0.5));
        sc += idf * (f * 2.2) / (f + 1.2 * (0.25 + 0.75 * d.len / AVG));
      }
      if (sc > 0) scored.push([sc, d.i]);
    }
    scored.sort((a, b) => b[0] - a[0]);
    const top = scored[0]?.[0] || 0;
    for (const [sc, i] of scored) { if (out.length >= n || sc < top * 0.45) break; push(i); }
  } else if (ref && !ref[1]) {
    for (const r of DATA.filter((r) => r.k === ref[0]).slice(0, n)) push(BY.get(r.k + "." + r.s));
  }
  return out.slice(0, n);
}

export const kandaTopics = (k) => DATA.filter((r) => r.k === k).map((r) => `${r.s}: ${r.t || r.d}`).join("; ");
export const COUNT = DATA.length;

// लंबे सूक्त से अंश: शुरुआत के मंत्र + प्रश्न से मेल खाते मंत्र (मूल क्रम में)
export function excerpt(r, query, max = 3200) {
  if (r.x.length <= max) return r.x;
  const blocks = r.x.split(/(?<=\(\s*[०-९\d]+\s*\))\s*\n/);
  // block pairs: mantra + its meaning end with the same "(n)"
  const qt = new Set(terms(query));
  const scored = blocks.map((b, i) => {
    let sc = 0; for (const t of terms(b)) if (qt.has(t)) sc++;
    return { i, b, sc: i < 2 ? 1000 - i : sc };
  });
  const pick = new Set(); let len = 0;
  for (const s of [...scored].sort((a, b) => b.sc - a.sc || a.i - b.i)) {
    if (len + s.b.length > max) continue;
    pick.add(s.i); len += s.b.length;
    if (s.sc > 0 && s.i % 2 === 0 && blocks[s.i + 1] && !pick.has(s.i + 1) && len + blocks[s.i + 1].length <= max) { pick.add(s.i + 1); len += blocks[s.i + 1].length; }
  }
  const idx = [...pick].sort((a, b) => a - b);
  let out = "", prev = -1;
  for (const i of idx) { out += (prev >= 0 && i !== prev + 1 ? "\n…\n" : prev >= 0 ? "\n" : "") + blocks[i]; prev = i; }
  return out + "\n…(सूक्त के शेष मंत्र यहाँ नहीं दिए गए)";
}
